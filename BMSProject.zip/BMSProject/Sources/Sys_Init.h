/*=======================================================================
 *Subsystem:   ���
 *File:        Sys_Init.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _SYS_INIT_H_
#define _SYS_INIT_H_  

  #include"TypeDefinition.h"

  typedef struct
  {
    ADC;
    IIC;
    PIT;
    PLL;
    GPIO;
    EEPROM;
    CAN;
    SCI; 
    AllInit_State;   //0:
   
   
   
    
  }System_InitState_T;
  extern System_InitState_T System_InitState;
  
  
  
#endif  


                                                                         
