/*=======================================================================
 *Subsystem:   ���
 *File:        Roll_Task.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _ROLL_TASK_H_
#define _ROLL_TASK_H_

  /*========================================================
                      ϵͳ��/�ŵ�״̬�ж�
                      WorkStateJudge_T
  ========================================================*/
  typedef struct
  {
    uint8  WorkState;                       //����״̬
    uint8  WorkState_EnterTime_DisCharge;   // �ŵ�״̬�����ʱ   
    uint8  WorkState_EnterTime_Charge;      // ���״̬�����ʱ     
    uint8  WorkState_EnterFlag;             // ����ŵ�����м�¼
  }WorkStateJudge_T;
  extern WorkStateJudge_T  WorkStateJudge;  

/*==========================================================
                        ������ѯʱ���ʱ
                        Task_Roll_Time_T
==========================================================*/
  









#endif