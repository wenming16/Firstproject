/*=======================================================================
 *Subsystem:   ���
 *File:        Task_BMSCheckSelf.C
 *Author:      WenYuhao
 *Description: ͨ�ţ�
               �ӿڣ�
               �����ʣ�
               ֻ���Լ�ɹ�����ܱպ���Ӧ�Ŀ���
/* ========================================================================
 * History:    �޸���ʷ��¼�б���
 * 1. Date:    
      Author:  
      Modification: 
========================================================================*/
#include "Task_BMSCheckSelf.h"  

BMSCheckSelf_T  BMSCheckSelf;

/*=======================================================================
 *������:      BMSCheckSelf(void)
 *����:        BMS�Լ캯��
 *����:        ��       
 *���أ�       ��
 *˵����       BMS�Լ첻ͨ�����򲻱պ������̵��������Ҳ��ܳ��
========================================================================*/  
/*void BMSCheckSelf() 
{
  BMSCheckSelf.Check_Self = 0x00;         //�Լ���
  //ADC     
  if()
  {
    BMSCheckSelf.Check_Self |= 0x0001;   
  }
  else
  {
    BMSCheckSelf.Check_Self &= 0x00FE; 
  }
  //IIC           
  if()
  {  
    BMSCheckSelf.Check_Self |= 0x0002;     
  } 
  else
  {
    BMSCheckSelf.Check_Self &= 0x00FD;
  }
  //PIT
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  //PLL
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  //GPIO
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  //EEPROM
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  //CAN
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  //SCI
  if() 
  {                           
     BMSCheckSelf.Check_Self |= 0x0004; 
  }
  else
  {         
     BMSCheckSelf.Check_Self &= 0x00FB;               
  }
  
  if(Task_WorkMode.Check_Self == 0)
    BMSCheckSelf.Check_Self_state = 0x01;//�Լ�ɹ�
  else
    BMSCheckSelf.Check_Self_state = 0x02;//�Լ�ʧ��
   
   
  //Task_Flag_Counter.Counter_BMSCheckSelf++;
}*/