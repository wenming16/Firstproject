#ifndef _DATA_FROM_CSSU_H_
#define _DATA_FROM_CSSU_H_

  void DataFromCSSU(pCANFRAME data);

#endif