/*=======================================================================
 *Subsystem:   ���
 *File:        Delay_Function.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _DELAY_FUNCTION_H_
#define _DELAY_FUNCTION_H_  

  #include"TypeDefinition.h"
  
  void delay(void);

  //void delay_init(void);
  //void delay_init2(void);

  void delayus(uint16);
  
#endif   