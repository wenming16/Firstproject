#ifndef _TASK_VOLTCOLLECT_H_
#define _TASK_VOLTCOLLECT_H_ 
   
   void Task_VoltCMDSend(void);
   void Task_VoltCollect(void);
   void Task_TempCMDSend(void);
   void Task_TempCollect(void);
   void Task_OpenWireDetect(void)
   
#endif