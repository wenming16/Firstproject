/*=======================================================================
 *Subsystem:   ���
 *File:        Init_SOC.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef  _INIT_SOC_H_
#define  _INIT_SOC_H_

  float inition_soc(float v);

#endif