/*=======================================================================
 *Subsystem:   ���
 *File:        Init_Flash.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _INIT_DFLASHPFLASH_H_
#define _INIT_DFLASHPFLASH_H_
   
   #include  "TypeDefinition.h"
  
   uint8 Init_Flash(void);
   
#endif