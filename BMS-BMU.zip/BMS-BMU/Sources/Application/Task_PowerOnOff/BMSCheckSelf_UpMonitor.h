#ifndef _BMSCHECKSELF_UPMONITOR_H_
#define _BMSCHECKSELF_UPMONITOR_H_

    #include  "TypeDefinition.h"
    #include  "Init_Sys.h"
    #include  "BMSCheckSelf.h"     
    
    void BMSCheckself_UpMonitor(SysInitState_T*sysint, Flt_BMSCheckSelf_T*lev2);

#endif