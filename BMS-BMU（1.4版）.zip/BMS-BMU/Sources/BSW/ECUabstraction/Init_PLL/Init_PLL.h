/*=======================================================================
 *Subsystem:   ���
 *File:        Init_PLL.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _INIT_PLL_H_
#define _INIT_PLL_H_  

  #include  "TypeDefinition.h"

  uint8 Init_PLL(void);

#endif