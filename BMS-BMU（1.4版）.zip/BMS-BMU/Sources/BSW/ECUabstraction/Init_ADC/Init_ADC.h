/*=======================================================================
 *Subsystem:   ���
 *File:        Init_ADC.h
 *Author:      WenYuhao
 *Description: 
 ========================================================================
 * History:    
 * 1. Date:
      Author:
      Modification:
========================================================================*/

#ifndef _INTERLAYER_INIT_ADC_H_
#define _INTERLAYER_INIT_ADC_H_

 #include "TypeDefinition.h"
 
 uint8 Init_ADC(void);



#endif